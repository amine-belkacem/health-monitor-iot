Gerbers RS-274X, 2 couches, 120 x 75 mm.
Piste MQ_AOUT sur la couche bottom (plan de masse decoupe).
Fichier de percage : Excellon, mm.
Reconstruction : a verifier avant toute fabrication.
